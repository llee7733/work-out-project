ActiveModelSerializers.config.tap do |c|
  # c.adapter = :json_api   //introduces too much uneeded info in the JSON object
  # c.jsonapi_include_toplevel_object = true
  # c.jsonapi_version = "1.0"
end
