class ExerciseDay < ApplicationRecord
  belongs_to :exercise
  belongs_to :day 
end
