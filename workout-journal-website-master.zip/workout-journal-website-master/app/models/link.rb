class Link < ApplicationRecord
  validates :name, :presence => true 
end
