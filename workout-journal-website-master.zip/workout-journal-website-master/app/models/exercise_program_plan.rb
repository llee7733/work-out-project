class ExerciseProgramPlan < ApplicationRecord
  belongs_to :exercise
  belongs_to :program_plan

end
