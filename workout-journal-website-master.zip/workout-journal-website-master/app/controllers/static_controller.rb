class StaticController < ApplicationController


end
